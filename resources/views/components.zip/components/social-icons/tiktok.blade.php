
<svg xmlns="http://www.w3.org/2000/svg" {{ $attributes }} viewBox="0 0 24 24" fill="none">
    <path d="M19.321 5.562c-1.247-.644-2.121-1.848-2.315-3.245h-3.006v13.066c0 1.763-1.25 3.177-2.947 3.177-1.697 0-2.946-1.414-2.946-3.177 0-1.763 1.25-3.177 2.946-3.177.326 0 .64.06.943.154V9.392c-.302-.05-.614-.082-.943-.082-3.283 0-5.947 2.714-5.947 6.06 0 3.344 2.664 6.059 5.947 6.059 3.282 0 5.947-2.715 5.947-6.06V8.8c1.228.847 2.722 1.352 4.34 1.352V7.175c-.035 0-.072.005-.107.005-.8 0-1.55-.372-2.035-.983-.41-.516-.668-1.162-.668-1.866 0-.039 0-.077.002-.116" 
      strokeWidth="2" stroke="black" strokeLinecap="round" strokeLinejoin="round"
      fill="url(#tiktok-gradient)"></path>
    <defs>
      <linearGradient id="tiktok-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#25F4EE" />
        <stop offset="50%" stopColor="#000000" />
        <stop offset="100%" stopColor="#FE2C55" />
      </linearGradient>
    </defs>
  </svg>
