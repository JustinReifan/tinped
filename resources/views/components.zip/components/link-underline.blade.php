
<a href="{{ $href ?? '#' }}" class="link-underline {{ $class ?? '' }}" aria-label="{{ $slot }}">
    {{ $slot }}
</a>
